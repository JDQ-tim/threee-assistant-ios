# 编译结果

## 发现的问题（按文件:行:列）

```
ThreeeAssistant/Core/SystemCalendar.swift:328:56: warning: main actor-isolated static property 'oursTitle' can not be referenced from a non-isolated context; this is an error in Swift 6
ThreeeAssistant/Core/SystemCalendar.swift:328:56: warning: main actor-isolated static property 'oursTitle' can not be referenced from a non-isolated context; this is an error in Swift 6
```

错误数：0
警告数：2
Swift 编译记录：192 条

## 契约回归（真实响应解码）
```
----------------------------------------------------------
✅ HealthDTO
✅ BootstrapResponse
✅ CalendarsResponse
✅ SyncSnapshotResponse
✅ TierInfoDTO
✅ UsersResponse
✅ SiteInviteDTO
✅ ModerationMetaDTO
✅ WeatherLocationDTO
✅ CoursePeriodsResponse
✅ WeatherDocDTO
✅ WordbookHealthDTO
✅ WordbookPullResponse
✅ InboxListResponse
✅ TeamsResponse
✅ TeamDetailResponse
✅ TeamInvitesResponse
✅ CalendarInvitesResponse
✅ CalendarTeamSharesResponse
----------------------------------------------------------
解码 19 个，失败 0 个

自检：改坏的 fixture 被正确拒绝 ✅
```

## 请求契约（发的键 vs 读的键）
```
✅ WordbookPushRequest  →  wordbookPushReq
    客户端发 2 键，服务端读 2 键
    字段名完全对齐

✅ SyncPushRequest  →  pushReq
    客户端发 2 键，服务端读 2 键
    字段名完全对齐

✅ SetWeatherLocationBody  →  weatherLocationReq
    客户端发 3 键，服务端读 3 键
    字段名完全对齐

================================================================
全部对齐
```

## 实时活动（锁屏该挂哪一节）
```
实时活动选课自检：17 通过 / 0 失败（共 17 项）
```

## 提醒排程（哪些通知该排）
```
提醒排程校验：/Users/runner/work/threee-assistant-ios/threee-assistant-ios/Tests/fixtures/SyncSnapshotResponse.json
----------------------------------------------------------
真实数据：17 个实例 / 1 条提醒配置
----------------------------------------------------------
断言 19 条，失败 0 条
✅ 全部通过
```

## 真机安装包（不用 Mac 也能装）
✅ 已生成 **未签名 IPA**：下载下面的 `ThreeeAssistant-device-ipa` 附件。

装到 iPhone 上（Windows 全程够用）：
1. 装 [Sideloadly](https://sideloadly.io/) 和「Apple 设备」应用（微软商店搜 Apple Devices）
2. 手机连电脑，解锁并「信任此电脑」
3. Sideloadly 里选 IPA，Apple ID 填自己的，点 Start 签名安装
4. 手机上「设置 → 通用 → VPN与设备管理」里信任这个开发者

> 免费 Apple ID 签的包 **7 天过期**，到期在 Sideloadly 里重签一次。

## 结论
✅ **编译通过**（192 条编译记录，说明确实编译了）
